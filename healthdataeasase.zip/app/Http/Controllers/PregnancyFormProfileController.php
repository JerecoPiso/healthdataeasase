<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PregnancyFormProfileController extends Controller
{
    //
}
