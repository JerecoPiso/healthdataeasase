<template>
     <main class=" dark:bg-gray-900 h-screen">
        <RouterView />
    </main>
</template>
<script setup>
import { RouterView } from 'vue-router';
</script>