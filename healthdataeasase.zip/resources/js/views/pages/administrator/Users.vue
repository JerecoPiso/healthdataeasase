<template>
    <div class="card">

    </div>
</template>
<script setup>

</script>