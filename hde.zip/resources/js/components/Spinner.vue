<template>
    <div class="w-full flex justify-center items-center">
        <v-icon name="fa-spinner" scale="3" class="z-90  animate-spin"></v-icon>
    </div>
</template>