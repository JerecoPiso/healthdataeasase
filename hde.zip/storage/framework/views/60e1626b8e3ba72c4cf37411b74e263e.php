<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Households</title>
    <link rel="stylesheet" href="<?php echo e($css_path); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/report.css')); ?>"> -->
</head>
<style>

</style>

<body>
    <div class="header">
        <div class="header-logo">
            <img src="<?php echo e($img_path); ?>" alt="Sta Fe" class="logo">
        </div>
        <div class="header-title">
            <p>HEALTH DATA EASE <br /> STA. FE LEYTE</p>
        </div>
        <div class="header-logo">
            <img src="<?php echo e($img_path); ?>" alt="Sta Fe" class="logo">
        </div>
    </div>
    <!-- <div class="header">
        <div class="header-logo">
            <img src="<?php echo e(asset('images/stafe.png')); ?>" alt="Sta Fe" class="logo">
        </div>
        <div class="header-title">
            <p>HEALTH DATA EASE <br /> STA. FE LEYTE</p>
        </div>
        <div class="header-logo">
            <img src="<?php echo e(asset('images/stafe.png')); ?>" alt="Sta Fe" class="logo">
        </div>
    </div> -->
    <?php
    $previousHouseholdNumber = null;
    $rowspanCount = 0;
    ?>
    <?php if(!empty($profiles) && $profiles->count()): ?>
    <p class="label " style="text-align: center">Households: (<?php echo e($purok); ?>)</p>
    <div>
        <table>
            <thead>
                <tr>
                    <th>House #</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Birthdate</th>
                    <th>Civil Status</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($p->household_profile_id !== $previousHouseholdNumber): ?>
                <?php
                // Count the number of profiles with the same household_profile_id
                $rowspanCount = $profiles->where('household_profile_id', $p->household_profile_id)->count();
                $previousHouseholdNumber = $p->household_profile_id;
                ?>
                <tr>
                    <td rowspan="<?php echo e($rowspanCount); ?>" style="width: 10em;"><?php echo e($p->household_number); ?></td>
                    <td><?php if($p->id == $p->personal_profile_id): ?> <span class="household-head">(HEAD)</span> <?php endif; ?> <?php echo e($p->firstname . ' ' . $p->middlename . ' ' . $p->lastname . ' ' . $p->suffix); ?></td>
                    <td><?php echo e($p->sex); ?></td>
                    <td><?php echo e($p->birthdate); ?></td>
                    <td><?php echo e($p->civil_status); ?></td>

                </tr>
                <?php else: ?>
                <tr>
                    <td><?php if($p->id == $p->personal_profile_id): ?> <span class="household-head">(HEAD)</span> <?php endif; ?> <?php echo e($p->firstname . ' ' . $p->middlename . ' ' . $p->lastname . ' ' . $p->suffix); ?></td>
                    <td><?php echo e($p->sex); ?></td>
                    <td><?php echo e($p->birthdate); ?></td>
                    <td><?php echo e($p->civil_status); ?></td>

                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <p style="margin-top: 20px;">
        <strong>As of:</strong> <?php echo e(\Carbon\Carbon::now()->format('F j, Y g:i a')); ?>

    </p>
    <?php else: ?>

    <p style="text-align: center">No result found.</p>
    <?php endif; ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\healthdataease\resources\views//reports/household.blade.php ENDPATH**/ ?>