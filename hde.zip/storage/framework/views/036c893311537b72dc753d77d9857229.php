<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Senior Citizens</title>
    <link rel="stylesheet" href="<?php echo e($css_path); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/report.css')); ?>"> -->
</head>
<style>

</style>
<body>
    <div class="header">
        <div class="header-logo">
            <img src="<?php echo e($img_path); ?>" alt="Sta Fe" class="logo">
        </div>
        <div class="header-title">
            <p>HEALTH DATA EASE <br /> STA. FE LEYTE</p>
        </div>
        <div class="header-logo">
            <img src="<?php echo e($img_path); ?>" alt="Sta Fe" class="logo">
        </div>
    </div>
    <!-- <div class="header">
        <div class="header-logo">
            <img src="<?php echo e(asset('images/stafe.png')); ?>" alt="Sta Fe" class="logo">
        </div>
        <div class="header-title">
            <p>HEALTH DATA EASE <br /> STA. FE LEYTE</p>
        </div>
        <div class="header-logo">
            <img src="<?php echo e(asset('images/stafe.png')); ?>" alt="Sta Fe" class="logo">
        </div>
    </div> -->
    <?php if(!empty($seniors) && $seniors->count()): ?>
    <p class="label">Senior Citizens:</p>
    <div>
        <table>
            <thead>
                <tr>
               
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Age</th>
                    <th>Birthdate</th>
                    <th>Civil Status</th>
                    <th>Educational Attainment</th>
                    <th>Work</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $seniors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
                <tr>
                    <td> <?php echo e($s->lastname . ' ' . $s->firstname . ' ' .  $s->middlename . ' '. $s->suffix); ?></td>
                    <td><?php echo e($s->sex); ?></td>
                    <td><?php echo e($s->age); ?></td>
                    <td><?php echo e($s->birthdate); ?></td>
                    <td><?php echo e($s->civil_status); ?></td>
                    <td><?php echo e($s->educational_attainment); ?></td>
                    <td><?php echo e($s->work); ?></td>
                </tr>
          
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <p style="margin-top: 20px;">
        <strong>Date:</strong> <?php echo e(\Carbon\Carbon::now()->format('F j, Y')); ?>

    </p>
    <?php else: ?>
    <p style="text-align: center">No result found.</p>
    <?php endif; ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\healthdataease\resources\views//reports/seniorcitizen.blade.php ENDPATH**/ ?>