<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Age Range</title>
    <link rel="stylesheet" href="<?php echo e($css_path); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/report.css')); ?>"> -->
</head>
<style>

</style>

<body>
    <div class="header">
        <div class="header-logo">
            <img src="<?php echo e($img_path); ?>" alt="Sta Fe" class="logo">
        </div>
        <div class="header-title">
            <p>HEALTH DATA EASE <br /> STA. FE LEYTE</p>
        </div>
        <div class="header-logo">
            <img src="<?php echo e($img_path); ?>" alt="Sta Fe" class="logo">
        </div>
    </div>
    <!-- <div class="header">
        <div class="header-logo">
            <img src="<?php echo e(asset('images/stafe.png')); ?>" alt="Sta Fe" class="logo">
        </div>
        <div class="header-title">
            <p>HEALTH DATA EASE <br /> STA. FE LEYTE</p>
        </div>
        <div class="header-logo">
            <img src="<?php echo e(asset('images/stafe.png')); ?>" alt="Sta Fe" class="logo">
        </div>
    </div> -->
    <?php if(!empty($members) && $members->count()): ?>
    <p class="label"><?php echo e('Age between '. $minAge . ' and ' . $maxAge); ?>:</p>

    <div>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Age</th>

                    <th>Gender</th>
                    <th>Birthdate</th>
                    <th>Civil Status</th>
                    <th>Educational Attainment</th>
                    <th>Work</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($m->lastname . ' ' . $m->firstname . ' ' .  $m->middlename . ' '. $m->suffix); ?></td>
                    <td><?php echo e($m->age); ?></td>
                    <td><?php echo e($m->sex); ?></td>
                    <td><?php echo e($m->birthdate); ?></td>
                    <td><?php echo e($m->civil_status); ?></td>
                    <td><?php echo e($m->educational_attainment); ?></td>
                    <td><?php echo e($m->work); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <p style="margin-top: 20px;">
        <strong>Date:</strong> <?php echo e(\Carbon\Carbon::now()->format('F j, Y')); ?>

    </p>
    <?php else: ?>
    <p style="text-align: center">No result found.</p>
    <?php endif; ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\healthdataease\resources\views//reports/reportByAgeRange.blade.php ENDPATH**/ ?>