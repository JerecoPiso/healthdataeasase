<template>
    <span class="text-red-500 text-xl">*</span>
</template>